# Subtitle workflow

Use this workflow only after the approved conform is locked. The final video is the subtitle timebase and the final SRT uses the same basename.

## 1. Inspect and prepare

- Search the project and final-video directory for SRT, VTT, ASS, transcripts, and timecoded ASR JSON before transcribing.
- Probe the final video's exact duration and audio stream. Extract 16 kHz, 16-bit mono audio from that final.
- Keep raw text, provider responses, chunks, alignment data, and QA logs under `work/subtitles-vNN/`; keep them out of `delivery/`.
- Use `https://api.stepfun.com/step_plan/v1` as the single StepFun API base. Derive synchronous and asynchronous ASR paths from it and override only through `STEPFUN_API_BASE_URL`.
- Resolve credentials in this order: macOS Keychain service `STEPFUN_API_KEY`, environment `STEPFUN_API_KEY`, then `STEP_API_KEY`. Never print or persist a raw key.
- If the preferred provider is unavailable, stop before switching to a local or different cloud ASR. Obtain user approval for the fallback and disclose its resource/privacy impact.

## 2. Obtain text and timestamps

For Chinese, use `stepaudio-2.5-asr` for the main text with language `zh` and ITN enabled. Treat its HTTP/SSE text as text only when returned timestamps are all zero or incomplete.

Use a timestamp source that returns real utterance or word boundaries:

1. Prefer StepFun asynchronous file ASR with `step-asr-1.1` and `show_utterances=true`.
2. Supply 16 kHz mono MP3/WAV under the provider's size limit through a private or temporary HTTPS URL. Expose only the intended audio. Keep the URL alive until the ASR task reaches a terminal state; an initial GET does not prove the provider will not download again after queueing.
3. Close the tunnel immediately after all tasks finish. Delete any explicitly created provider file object when authorized.
4. Treat `PENDING`, `QUEUED`, `SUBMITTED`, and `RUNNING` as non-terminal. Treat a response with results as success. Preserve the exact error stage and message on failure.
5. Back off on HTTP 429 rather than resubmitting successful tasks.

Do not deliver an SRT from zero timestamps, missing continuous-speech timestamps, or character-proportional timing.

## 3. Recover blocked or failed long audio

- First submit the whole file when safe and supported.
- If the whole file is risk-blocked, download-blocked, or lacks complete timestamps, split the locked-final audio into approximately three-minute windows with about 1.5 seconds of overlap on each side.
- Keep only words whose midpoint falls inside the window's non-overlap core. This removes duplicates without discarding boundary speech.
- If an individual three-minute window fails, split only that core into approximately one-minute windows with the same overlap/core rule.
- Save task IDs and results per window so the job can resume without retranscribing completed windows.
- If the shorter online windows still fail, report the exact final-video time ranges. Ask before using local Whisper or another provider.

## 4. Build and proofread cues

- Create a glossary before proofreading: canonical people and pronouns, programs, works, products, venues, organizations, dates, numbers, technical terms, aliases, and known ASR confusions.
- Align the StepAudio text to provider word timestamps. If asynchronous text and StepAudio text are materially identical, the timestamped words may be used directly after proofreading; otherwise use character/word sequence alignment while retaining real word boundaries.
- Group at pauses, hard sentence endings, or a visible-length limit. Default to about 16 Chinese characters and roughly 0.35–5 seconds per cue.
- Remove non-semantic `啊`, `嗯`, `呃`, repeated starts, and obvious stutters. Preserve meaningful repetition, emotion, jokes, names, numbers, and claims.
- Correct names, programs, venues, locations, brands, dates, and technical terms from authoritative sources. Keep a timecoded uncertainty list for anything not safely inferable and ask the user instead of guessing.
- Avoid ordinary Chinese sentence-final punctuation for the cleaned house style. Do not split a person name, fixed term, or Latin brand such as `HALF Coffee` across cues.
- Keep cue times strictly increasing and non-overlapping. When a provider returns equal or zero-length word boundaries, extend only enough to create a valid cue without moving the next cue earlier.

## 5. Validate and deliver

Require all of the following:

- UTF-8 SRT with sequential one-based cue numbers.
- Parseable `HH:MM:SS,mmm --> HH:MM:SS,mmm` timestamps.
- Positive durations, no overlaps, no empty cues, and final cue end at or before final-video duration.
- No unintended lines beyond the chosen visible-length limit; allow a documented exception for an indivisible verified term.
- Spot checks at opening, early section, midpoint, ending, all conform joins, provider-window boundaries, and every drift-correction region.
- A manual scan for names, homophones, pronouns, repeated phrases, numbers, and ASR hallucinations.

Run:

```bash
python3 scripts/validate_srt.py work/subtitles-v01/draft.srt \
  --video versions/videos/locked-final.mp4 \
  --bad-term 何菜头=和菜头 \
  --json-out work/subtitles-v01/qa/subtitle-qa.json
```

Use `--allow-punctuation` only when the user explicitly chooses a punctuation-preserving subtitle style. Write to a partial filename, validate it, hash it, then atomically rename it beside the video. Refuse an existing destination. Record text model, timestamp model, coverage, cue count, unresolved terms, QA results, and delivery hash in a subtitle QA summary outside `delivery/`.
