import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from PIL import Image
ROOT=Path(__file__).resolve().parents[1]

class HeadframeCompatibilityTests(unittest.TestCase):
    def test_actual_headframe_extract_decode_and_source_preservation(self):
        with tempfile.TemporaryDirectory(prefix='headframe-compat-') as tmp:
            work=Path(tmp).resolve();source=work/'source.mp4'
            subprocess.run(['ffmpeg','-v','error','-f','lavfi','-i','testsrc2=size=320x240:rate=30:duration=2','-c:v','libx264','-preset','ultrafast','-pix_fmt','yuv420p',str(source)],check=True)
            before=hashlib.sha256(source.read_bytes()).hexdigest()
            cfg=work/'config.json';cfg.write_text(json.dumps({'output_dir':str(work/'frames'),'jobs':[{'id':'probe','video':str(source),'timestamps':[.2,.8,1.5]}]}))
            result=subprocess.run([sys.executable,'-B',str(ROOT/'scripts/extract_headframe_candidates.py'),str(cfg)],capture_output=True,text=True,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
            self.assertEqual(result.returncode,0,result.stdout+result.stderr)
            images=list((work/'frames/probe/original').glob('*.png'));self.assertEqual(len(images),3)
            for image in images:
                with Image.open(image) as opened: self.assertEqual(opened.size,(320,240));opened.verify()
            self.assertEqual(hashlib.sha256(source.read_bytes()).hexdigest(),before)

if __name__=='__main__':unittest.main()
