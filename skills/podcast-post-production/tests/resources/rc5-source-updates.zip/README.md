rc5 pinned source compatibility changes and guard adapters. Offline data; original repositories remain maintenance sources. Does not require network access for package tests.
